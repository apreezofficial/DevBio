  <div class="border-t border-gray-700 mt-12 pt-6 text-center text-xs text-gray-900 dark-text-gray-700 select-none">
  Made with love By <a href="https://preciousadedokun.com.ng" class="underline text-blue-700 dark-text-blue-200">Precious Adedokun</a> &copy; <?php echo date('Y'); ?>
  </div>